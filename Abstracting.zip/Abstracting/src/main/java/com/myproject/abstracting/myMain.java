/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.abstracting;

/**
 *
 * @author user01
 */
public class myMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Car car = new Car("Jake", 5,2000);
        
        car.setPrice();
        System.out.println(car.getPowerSource());
        System.out.println(car.getWheels());
        System.out.println(car.getPrice());
    }
    
}
