/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.abstracting;

/**
 *
 * @author user01
 */
public abstract class Vehicle {
    private String powerSource;
    private int wheels;
    protected int price;
    
     public Vehicle(String powerSource, int wheels){
         setPowerSource(powerSource);
         setWheels(wheels);
         setPrice();
    }   
      
public String getPowerSource(){
    return powerSource;
}

public int getWheels(){
    return wheels;
}

public int getPrice(){
    return price;
}

public void setPowerSource(String powerSource){
    this.powerSource = powerSource;
}

public void setWheels(int wheels){
 this.wheels = wheels;  
}

protected abstract void setPrice();

}

