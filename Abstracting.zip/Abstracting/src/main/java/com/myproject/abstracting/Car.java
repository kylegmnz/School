/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.abstracting;

/**
 *
 * @author user01
 */
public class Car extends Vehicle{

    public Car(String powerSource, int wheels, int price){
        super(powerSource, wheels);
        super.price = price;
        
    }
    
    
    @Override
    protected void setPrice(){
        super.price = price;
    }
    
    @Override
     public void setPowerSource(String powerSource){
        super.setPowerSource(powerSource);
    }
     
    @Override
    public void setWheels(int wheels){
       super.setWheels(wheels);
    }
}
