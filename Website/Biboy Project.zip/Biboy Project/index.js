

  new Swiper('.product-warp', {

    
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  

  });

 
  
  
  

  const closing = document.getElementById('close');
  const cons1 = document.getElementById('consumables');
  const elect = document.getElementById('electrical');
  const indust = document.getElementById('industrial');
  const lubri = document.getElementById('lubricant');
  const cons2 = document.getElementById('cons');
  const elect2 = document.getElementById('ele');
  const indust2 = document.getElementById('indus');
  const lubri2 = document.getElementById('lubri');
  const items = document.getElementById('items');
  
  

cons1.addEventListener('click', event => {
    console.log("gumana");
    cons2.style.display = "block";
    closing.style.display = "block";
    items.style.filter = "blur(100px)";
cons2.animate(
  [
    { top: "100vh", opacity: 0 },
    { top: "40vh", opacity: 1 }
  ],
  {
    duration: 500,
    iterations: 1,
    easing: "ease-in-out",
    fill: "forwards",
  }
);

});

elect.addEventListener('click', event => {
  console.log("gumana");
  elect2.style.display = "block";
  closing.style.display = "block";
  items.style.filter = "blur(100px)";
  elect2.animate(
    [
      { top: "100vh", opacity: 0 },
      { top: "40vh", opacity: 1 }
    ],
    {
      duration: 500,
      iterations: 1,
      easing: "ease-in-out",
      fill: "forwards",
    }
  );
});

indust.addEventListener('click', event => {
  console.log("gumana");
  indust2.style.display = "block";
  closing.style.display = "block";
  items.style.filter = "blur(100px)";
  indust2.animate(
    [
      { top: "100vh", opacity: 0 },
      { top: "40vh", opacity: 1 }
    ],
    {
      duration: 500,
      iterations: 1,
      easing: "ease-in-out",
      fill: "forwards",
    }
  );
});
lubri.addEventListener('click', event => {
  console.log("gumana");
  lubri2.style.display = "block";
  closing.style.display = "block";
  items.style.filter = "blur(100px)";
  lubri2.animate(
    [
      { top: "100vh", opacity: 0 },
      { top: "40vh", opacity: 1 }
    ],
    {
      duration: 500,
      iterations: 1,
      easing: "ease-in-out",
      fill: "forwards",
    }
  );
});
closing.addEventListener('click', event => {
  console.log("closing");
  cons2.style.display = "none";
  elect2.style.display = "none";
  indust2.style.display = "none";
  lubri2.style.display = "none";
  closing.style.display = "none";
  items.style.filter = "blur(0)";
  
});