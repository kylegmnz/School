const iOne = document.getElementById('iOne');
const iTwo = document.getElementById('iTwo');
const result = document.getElementById('result');
const cal = document.getElementById('cal');
const add = document.getElementById('add');
const sub = document.getElementById('sub');
const operators = document.getElementById('operators');
let value;

cal.onclick = function(){
    const iiOne = parseInt(iOne.value);
    const iiTwo = parseInt(iTwo.value);
if (isNaN(iiOne) || isNaN(iiTwo)) {
    result.textContent = "Please enter valid numbers.";
    return;
}
    value = 0;
    const op = operators.value; 
switch(op){
    case 'add': 
    value = iiOne + iiTwo;
    result.textContent = value;
    break;
    case 'sub':
        value = iiOne - iiTwo;
        result.textContent = value;

    break;
    case 'divide':
        if (iiTwo === 0) {
            result.textContent = 0;
            return;
        }
        value = iiOne / iiTwo;
        result.textContent = value;
        break;
    case 'product':
        value = iiOne * iiTwo;
        result.textContent = value;
        break;
}

}