package com.myproject.carrental;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Result extends JFrame{

   private Renter rent;
   JLabel lblName = new JLabel();
   JLabel lblAge = new JLabel();
   
   
public Result(){
   super("Vehicle List");
   setSize(300,500);
   setLocationRelativeTo(null);
   setLayout(null);
   vehComponent(rent);
   setVisible(true);
   setDefaultCloseOperation(EXIT_ON_CLOSE);
   

   
   }
   
public void vehComponent(Renter rent){
   
      if (rent != null) {
            lblName.setText(rent.getName());
            lblAge.setText(String.valueOf(rent.getAge()));
            add(lblName);
            add(lblAge);
        } else {
            System.out.println("Rent object is null!");
        }
        lblName.setBounds(80, 160, 150, 30);  
        lblAge.setBounds(80, 190, 150, 30 );
   
       }
   
}
