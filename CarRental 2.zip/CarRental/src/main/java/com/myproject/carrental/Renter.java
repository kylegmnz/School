/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.carrental;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author user01
 */
public class Renter extends JFrame implements ActionListener{
    JLabel lblName = new JLabel("Name: ");
    JLabel lblAge = new JLabel("Age: ");
    JLabel lblAddress = new JLabel("Address: ");
    JLabel lblLicense = new JLabel("License: ");
    JTextField txtName = new JTextField();
    JTextField txtAge = new JTextField();
    JTextField txtAddress = new JTextField();
    JTextField txtLicense = new JTextField();
    JButton btnNext = new JButton("Next");
    
    
    
    public Renter(){
     super("Client Information");
     setSize(300,500);
     setLocationRelativeTo(null);
     setLayout(null);
     getContentPane().setBackground(Color.YELLOW);
     Components();
     
     setDefaultCloseOperation(EXIT_ON_CLOSE);
     setVisible(true);
    }
    // ---- COMPONENTS OF OUR CLIENT JFRAMES --- //
    public void Components(){
        add(lblName);
        add(lblAge);
        add(lblAddress);
        add(lblLicense);
        add(txtName);
        add(txtAge);
        add(txtAddress);
        add(txtLicense);
        add(btnNext);
        lblName.setBounds(10, 20, 150, 30);   
        lblAge.setBounds(10, 60, 150, 30);    
        lblAddress.setBounds(10, 100, 150, 30);
        lblLicense.setBounds(10, 160, 150, 30);
        txtName.setBounds(80, 20, 150, 30);   
        txtAge.setBounds(80, 60, 150, 30);    
        txtAddress.setBounds(80, 100, 150, 30);
        txtLicense.setBounds(80, 160, 150, 30);  
        btnNext.setBounds(80, 190, 150, 30);
        btnNext.addActionListener(this);
    }
    
    
    
    String age = txtAge.getText();

    
    public String getName(){
      return txtName.getText();
    }
    public int getAge(){
            try{
      return Integer.parseInt(age);
      }catch(NumberFormatException e){
        return 0;
      }
    }
    public String getAddress(){
      return txtAddress.getText();
    }
     public String getLicense(){
      return txtLicense.getText();
   }
    
    @Override
    public void actionPerformed(ActionEvent e){
       dispose();
      Vehicle veh = new Vehicle();
    }
    
    
    
}