/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.carrental;
import javax.swing.*;
/**
 *
 * @author user01
 */
public class MainRental {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Renter client = new Renter();
        
 // -------  Client INFO -------   //
        String cName = client.getName();
        int cAge = client.getAge();
        String cAddress = client.getAddress();
        String cLicense = client.getLicense();
// ------ List of Cars ----- //

        
        
        
        
       
    }
    
}
