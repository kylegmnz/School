//package com.myproject.carrental;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Vehicle extends JFrame{

   JLabel lblMustang = new JLabel("Mustang Models");
   JLabel lblLamborghini = new JLabel("Lamborghini Models");
   JLabel lblVios = new JLabel("Vios Models");
   JPanel background = new JPanel();
//SCALED IMAGES --------------------------------------------------------
   //MUSTANG FIRST PICTURE 
   ImageIcon oldMustang1 = new ImageIcon("mustang1.png");
   Image updateMustang1 = oldMustang1.getImage().getScaledInstance(80,100, Image.SCALE_SMOOTH);
   ImageIcon newMustang1 = new ImageIcon(updateMustang1);
   JLabel imgMustang1 = new JLabel(newMustang1); 
   //MUSTANG SECOND PICTURE
   ImageIcon oldMustang2 = new ImageIcon("mustang2.png");
   Image updateMustang2 = oldMustang2.getImage().getScaledInstance(100,130, Image.SCALE_SMOOTH);
   ImageIcon newMustang2 = new ImageIcon(updateMustang2);
   JLabel imgMustang2 = new JLabel(newMustang2);
   //MUSTANG THIRD PICTURE
   ImageIcon oldMustang3 = new ImageIcon("mustang3.png");
   Image updateMustang3 = oldMustang3.getImage().getScaledInstance(100, 130, Image.SCALE_SMOOTH);
   ImageIcon newMustang3 = new ImageIcon(updateMustang3);
   JLabel imgMustang3 = new JLabel(newMustang3);
   
   
public Vehicle(){
   super("Vehicle List");
   setIconImage(oldMustang1.getImage());
   setSize(400,500);
   setLocationRelativeTo(null);
   setLayout(null);
   setResizable(false);
   setMaximumSize(new Dimension(300, 500));
   vehComponent();
   setVisible(true);
   setDefaultCloseOperation(EXIT_ON_CLOSE);
   }


   
public void vehComponent(){
// ADDDDDSS COMPONENTS
//---------------------------------------------------      
//Label Add to JFRAME 
     add(lblMustang);
     add(lblLamborghini);
     add(lblVios);
//Images add to JFRAME
     add(imgMustang1);
     add(imgMustang2); 
     add(imgMustang3);
     
//Modifying added components to JFRAME 
//---------------------------------------------------
//Labels
     background.setBackground(Color.CYAN);
     background.setBounds(0,0, 400,500);
     lblMustang.setBounds(10, 80, 150, 30);
     lblLamborghini.setBounds(10, 200, 150, 30);
     lblVios.setBounds(10, 320, 150, 30);
//Images
     imgMustang1.setBounds(10, 125, 150, 50);
     imgMustang2.setBounds(120, 125, 150, 50);
     imgMustang3.setBounds(230, 125, 150, 50);
     
   
}

}